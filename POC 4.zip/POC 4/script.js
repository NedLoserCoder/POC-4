const botaoCat = document.getElementById('fetch-cat');
const imagemGato = document.getElementById('cat-img');
const mensagemDeErro = document.getElementById('error-message');

async function buscarGatoIMG() {
    try {
        let response = await fetch(`https://api.thecatapi.com/v1/images/search`);
        let data = await response.json();
        return data[0].url;
    } catch (error) {
        throw new Error('Falha ao buscar a imagem: ' + error.message);
    }
}

async function mostrarGatoIMG() {
    try {
        const catImgUrl = await buscarGatoIMG();
        imagemGato.src = catImgUrl;
        imagemGato.style.display = 'block';
        mensagemDeErro.style.display = 'none';
    } catch (error) {
        imagemGato.style.display = 'none';
        mensagemDeErro.textContent = error.message; 
        mensagemDeErro.style.display = 'block';
    }
}

botaoCat.addEventListener('click', mostrarGatoIMG);
